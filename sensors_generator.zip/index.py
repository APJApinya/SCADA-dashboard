import paho.mqtt.client as mqtt
import random
import json
import time
import os
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))  # Get script directory

# AWS IoT Core Configuration as MQTT Broker
AWS_IOT_ENDPOINT = "a1pshszkbt5ijx-ats.iot.ap-southeast-2.amazonaws.com"
AWS_PORT = 8883  # Secure MQTT port
AWS_TOPIC = "factory/sensors"

# Paths to Certificates
CERTIFICATE_PATH = os.path.join(BASE_DIR, "connect_device_package/Factory_sensors.cert.pem")
PRIVATE_KEY_PATH = os.path.join(BASE_DIR, "connect_device_package/Factory_sensors.private.key")
ROOT_CA_PATH = os.path.join(BASE_DIR, "connect_device_package/AmazonRootCA1.pem")

# Check if files exist
for path in [CERTIFICATE_PATH, PRIVATE_KEY_PATH, ROOT_CA_PATH]:
    if not os.path.exists(path):
        print(f"ERROR: Certificate file missing: {path}")

# Create MQTT Client
client = mqtt.Client(client_id="Factory_sensors", protocol=mqtt.MQTTv311)


# Callback function to check connection status (for debugging)
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to AWS IoT Core!")
        client.connected_flag = True  # Set flag when connected
    elif rc == 1:
        print("onnection refused - Incorrect protocol version")
    elif rc == 2:
        print("Connection refused - Invalid client identifier")
    elif rc == 3:
        print("Connection refused - Server unavailable")
    elif rc == 4:
        print("Connection refused - Bad Username/Password (Check AWS Certs)")
    elif rc == 5:
        print("Connection refused - Not Authorized (Check AWS Policy)")
    else:
        print(f"Failed to connect, return code {rc}")

def on_publish(client, userdata, mid):
    print(f"Message {mid} published!")
    
client.on_connect = on_connect
client.on_publish = on_publish

# Configure TLS/SSL Authentication
client.tls_set(ca_certs=ROOT_CA_PATH, certfile=CERTIFICATE_PATH, keyfile=PRIVATE_KEY_PATH)

# Connect to AWS IoT Core
client.connected_flag = False  # Track connection status

print("Attempting to connect to AWS IoT Core...")
client.username_pw_set(username="", password=None)
client.connect(AWS_IOT_ENDPOINT, AWS_PORT, 60)

client.loop_start()
time.sleep(3)  # Allow time for connection

while not client.connected_flag:
    print("Waiting for connection...")
    time.sleep(1)

print("Ready to publish messages!")

# MQTT Broker Configuration
# MQTT_BROKER = "mqtt.eclipseprojects.io"
# MQTT_PORT = 1883 # MQTT over unexcrypted TCP
# MQTT_TOPIC = "factory/sensors" # set topic for subscriber tp subscribe
# client = mqtt.Client()
# Ensure proper connection to the MQTT broker
# def on_connect(client, userdata, flags, rc):
#     if rc == 0:
#         print("Connected to MQTT Broker!")
#     else:
#         print(f"Failed to connect, return code {rc}")
# client.on_connect = on_connect
# client.connect(MQTT_BROKER, MQTT_PORT, 60)
# client.loop_start()  # Start MQTT loop in the background

# Function to Simulate Sensor Data
def generate_sensor_data():
    return {
        "machine_id": "M123",
        "temperature": round(random.uniform(20,100), 2),
        "pressure": round(random.uniform(900,1100),2),
        "humidity": round(random.uniform(30,80),2),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

# Publish Data to AWS IoT Core
while True:
    sensor_data = generate_sensor_data()
    payload = json.dumps(sensor_data)
    result = client.publish(AWS_TOPIC, payload)

    if result.rc == mqtt.MQTT_ERR_SUCCESS:
        print(f"[SUCCESS] Published: {payload}")
    else:
        print(f"[ERROR] Failed to publish message. Return Code: {result.rc}")

    time.sleep(2)

# Publish Data to MQTT Topic
# while True:
#     sensor_data = generate_sensor_data()
#     payload = json.dumps(sensor_data)

#     client.publish(MQTT_TOPIC, payload)
#     result = client.publish(MQTT_TOPIC, payload)
#     status = result.rc
#     if status == 0:
#         print(f"Published: {payload}")
#     else:
#         print("Failed to publish message.")

#     time.sleep(2) # Send data every 2 seconds